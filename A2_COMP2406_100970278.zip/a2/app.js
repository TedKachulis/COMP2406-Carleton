/*
To run this app first execute
npm install
to load npm modules listed in package.json file

*/

var http = require('http');
var WebSocketServer = require('ws').Server;
var ecStatic = require('ecstatic');

var gameInfo = {
	red: {},
	blue: {},
	puck: {}
};

//static file server
var server = http.createServer(ecStatic({root: __dirname + '/www'}));

var wss = new WebSocketServer({server: server});
wss.on('connection', function(ws) {
	var paddle = null; // assigns the paddle colour to the connection
	//console.log('Client connected');
	ws.on('message', function(msg) {
	  	var receivedObj = JSON.parse(msg);
	  	
	  	if ( paddle == null ) 
	  		paddle = receivedObj.sendingClient;

	  	if ( paddle == 'red' ) { 
	  		// Only update the relevant information contained in the object sent from
	  		// the red paddle ( puck and red paddle information )
	  		gameInfo.red.x = receivedObj.red.x; 
			gameInfo.red.y = receivedObj.red.y;
			if ( gameInfo.red.teamSize == null ) 
				gameInfo.red.teamSize = receivedObj.red.teamSize;
			gameInfo.red.score = receivedObj.scores.red;
			gameInfo.blue.score = receivedObj.scores.blue;
			gameInfo.puck.move = receivedObj.puck.move;
			gameInfo.puck.x = receivedObj.puck.x;
			gameInfo.puck.y = receivedObj.puck.y;

	  	}
	    else if ( paddle == 'blue' ) {
	    	// Update the blue paddle position and score
			gameInfo.blue.x = receivedObj.blue.x; 
			gameInfo.blue.y = receivedObj.blue.y;
			if ( gameInfo.blue.teamSize == null )
				gameInfo.blue.teamSize = receivedObj.blue.teamSize;
			gameInfo.blue.score = receivedObj.blue.score;
		}
		
	    broadcast( JSON.stringify(gameInfo) );
  	});
  	ws.on('close', function(code, message ) {
  		// When the connection is closed, set that team to null so that the game pauses
  		// until a new player joins and then it resumes
  		if (paddle == 'red') {
  			gameInfo.red.teamSize = null;
  		}
  		else {
  			gameInfo.blue.teamSize = null;
  		}
  	});
  	broadcast( JSON.stringify(gameInfo) );
});

function broadcast(msg) {
  wss.clients.forEach(function(client) {
    client.send(msg);
  });
}

server.listen(3000);
console.log('Server Running at http://127.0.0.1:3000  CNTL-C to quit');
