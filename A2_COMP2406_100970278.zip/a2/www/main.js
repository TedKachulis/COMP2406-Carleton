
	
//initiate websocket
var ws = new WebSocket('ws://' + window.document.location.host);

//declare vars that affect canvas sizing, change to change canvas size
var CANVAS_HEIGHT=700, CANVAS_WIDTH=1000, pi=Math.PI;

//declare keys + key codes that control p1 movement TODO:p2 movement
/*red*/var UPARROW = 38, DOWNARROW = 40;
//declare canvas var (will be turned to obj) and context, control
var canvas;
var context, control;

var gameScreen;

//declare var, will be objects (moving) 
var red, blue, puck; 

//------------Create Moving Objects--------------

//struct object p1
red = {
	//pos p1
	x: null,
	y: null,
	score: null,

	//Control of the player
	upKey: null,
	downKey: null,
	
	//size p1
	width: 30,
	height: 95,

	active: false,
	
	//obj update (moves up and down) and return
	update: function() {
		//key control
		if (control[this.upKey]) this.y -= 5;
		if (control[this.downKey]) this.y += 5;
		if ( this.y < 0 ) this.y = 0;
		if ( this.y + this.height > CANVAS_HEIGHT ) this.y = CANVAS_HEIGHT - this.height;
	},
	draw: function() {
		context.fillRect(this.x, this.y, this.width, this.height);
	}
};

//struct object p2
blue = {
	//pos p2
	x: null,
	y: null,
	score: null,
	
	//Control of the player
	upKey: null,
	downKey: null,

	active: false,

	//size p2
	width: 30,
	height: 95,
	
	//teamData
	teamSize: null,
	
	//obj update and return
	update: function() {
		//key control
		if (control[this.upKey]) this.y -= 5;
		if (control[this.downKey]) this.y += 5;
		if ( this.y < 0 ) this.y = 0;
		if ( this.y + this.height > CANVAS_HEIGHT ) this.y = CANVAS_HEIGHT - this.height;
	},
	draw: function() {
		context.fillRect(this.x, this.y, this.width, this.height);
	}
};

//struct object puck
puck = {
	//pos puck
	x: null,
	y: null,
	move: null,
	
	puckSize: 20,//the puck is an even sided obj so dont need independant width/height.... def puckSize
	speed: 8,//set puck movement speed, change VAL 'speed' to change speed
	
	//obj update (moves ball) and return
	update: function() {
		this.x += this.move.x;
		this.y += this.move.y;
		
		//case: puck goes off canvas Y axis
		if(0 > this.y || this.y+this.puckSize > CANVAS_HEIGHT) {
			this.move.y *= -1; //flips y direction
		}
		
		//paddle hit bounce update
		var paddleHitCheck = function(x1, y1, w1, h1, /*<-paddle...puck->*/ x2, y2, w2, h2){
			//this checks if the two objects are intersecting, by taking
			//the given respective objects positions and sizes and comparing 
			//them to other objs position and size. (uses size to know how far 
			//obj is from position, aka give it a HIT BOX)
			return x1 < x2+w2 && y1 < y2+h2 && x2 < x1+w1 && y2 < y1+h1;
		};
		
		//Check which direction ball is moving, compare paddle that is in that direction
		var paddle = this.move.x < 0 ? red : blue;
		
		//if it is a hit... calculate bounce angle and flip x to move other way
		if(paddleHitCheck(paddle.x, paddle.y, paddle.width, paddle.height, /*<-paddle ... puck->*/ this.x, this.y, this.puckSize, this.puckSize)){
			
			
			//calculate bounch angle
			var delta = (this.y+this.puckSize - paddle.y)/(paddle.height+this.puckSize);//picks either positive angle or negative angle for bounce
			var phi = 0.25*pi*(2*delta -1);//45 degree reflection from hit
			
			//mirror X pos/velocity to bounce off paddles at correct angles
			this.move.x = (paddle === red ? 1 : -1)*this.speed*Math.cos(phi); //again checks which paddle its hitting, referes to the var paddle up there.
			this.move.y = this.speed*Math.sin(phi);                              //^multiplies to change signs and bounce on respective paddles.
			//this.move.x *= -1;
		}
		
		//case: if goal is scored (if puck passes x boundary)
		if (0 > this.puckSize+this.x || this.x > CANVAS_WIDTH){
			//goal
			if(paddle === red){
				blue.score += 1;
			}
			else if(paddle === blue){
				red.score += 1;
			}
			
			
			//reset puck position
			puck.x = (CANVAS_WIDTH - puck.puckSize)/2;//start puck @ center (x)
			puck.y = (CANVAS_HEIGHT - puck.puckSize)/2;//start puck @ center (y)

			//reset puck movement velocity
			puck.move = {
				x: (paddle === red ? 1 : -1) * puck.speed,
				y: 0
			}
		}
		
		
		
	},
	
	//draw
	draw: function() {
		context.fillRect(this.x, this.y, this.puckSize, this.puckSize);
	}
};

//-------------------------------MAIN---------------------------------------

function main (){
	gameScreen = 0;
	//var canvas --> object
	canvas = document.createElement("canvas")
	//properties of canvas (to change, ref vars at top)
	canvas.width = CANVAS_WIDTH;
	canvas.height = CANVAS_HEIGHT;
	//context to 2d
	canvas.addEventListener('click', function(evt) {
		switch ( gameScreen ) {
			case 0:
				// Object to be sent to the server with the initial information
				var updateObject = { 
					red: red,
					blue: blue,
					puck: puck,
					scores: {
						red: red.score,
						blue: blue.score
					}
				}
				if ( evt.layerX < CANVAS_WIDTH / 2 && red.teamSize == null ) {
					assignRed();
					// Output the starting values to the server
					updateObject.sendingClient = "red";
				
				}
				else if ( blue.teamSize == null ) {
					assignBlue();
					updateObject.sendingClient = "blue";
				}
				ws.send ( JSON.stringify(updateObject) );
				gameScreen = 1;
				break;
			default:
				break;
		}
	});
	context = canvas.getContext("2d");
	document.body.appendChild(canvas);//append canvas ctx to the document sizing
	
	//key control 
	control = {};
	
	//listens for keypress (down)
	document.addEventListener("keydown", function(evt){
		control[evt.keyCode] = true;
	});
	
	//listens for keypress (up)
	document.addEventListener("keyup", function(evt){
		delete control[evt.keyCode];
	});
	
	init();
	
	//draw and update loop
	var bufferLoop = function() {
		update();//update
		draw();//prepare draw to client/canvas
		//send frames / update elements
		window.requestAnimationFrame(bufferLoop, canvas);
	};
	//^
	window.requestAnimationFrame(bufferLoop, canvas);
}

//-------------------endMAIN---------------------------------------------

//-------------------BUTTON FUNCTIONS------------------------------------

//assign to red team
function assignBlue(){
	
	if (blue.teamSize == null){
		blue.teamSize = 1;
		
		// Set the up and down arrows to control the blue paddle
		blue.upKey = UPARROW;
		blue.downKey = DOWNARROW;
		blue.active = true;
	}
}


function assignRed(){
	
	if (red.teamSize == null){
		red.teamSize = 1;
		
		// Set the up and down arrows to control the red paddle
		red.upKey = UPARROW;
		red.downKey = DOWNARROW;
		red.active = true;
	}
}



function init() {
	startGame();

}

function startGame() {
	//start positions of objects/elements--------------------------------
	//Start score
	red.score = 0;
	blue.score = 0;
	
	//p1 positions
	red.x = red.width;//p1 pos (x)
	red.y = (CANVAS_HEIGHT - red.height)/2;//p1 pos (y)
	
	//p2 positions
	blue.x = CANVAS_WIDTH - (red.width + blue.width);//p2 pos (x)
	blue.y = (CANVAS_HEIGHT - blue.height)/2;//p2 pos (y)
	
	//puck position
	puck.x = (CANVAS_WIDTH - puck.puckSize)/2;//start puck @ center (x)
	puck.y = (CANVAS_HEIGHT - puck.puckSize)/2;//start puck @ center (y)
	
	puck.move = {
		x: puck.speed,
		y: 0
	}

	// Update server if blue
}

//update buffer to draw
function update() {
	// If both players are connected to the server then update
	if ( blue.teamSize != null && red.teamSize != null ) {
		// Update puck position from server if red team, set puck position if from blue
		if ( red.active == true ) {
			puck.update();
			red.update();
			ws.send(JSON.stringify({ red:red, puck:puck, scores: { red:red.score, blue:blue.score } }));
		}
		else if ( blue.active == true ) {
			blue.update();
			ws.send(JSON.stringify({ blue: blue }));
		}
	}

}

//draw to canvas
function draw() {
	switch ( gameScreen ) {
		case 0: // Choose Team screen
			// Join Blue side
			context.fillStyle = "#FA5858";
			context.fillRect( 0,0, CANVAS_WIDTH / 2, CANVAS_HEIGHT );
			// Join Red side
			context.fillStyle = "#2E64FE";
			context.fillRect( CANVAS_WIDTH / 2, 0, CANVAS_WIDTH / 2, CANVAS_HEIGHT);
			// Text
			context.font = "30px Verdana";
			context.fillStyle = "#F5F6CE";
			context.fillText(red.teamSize == null ? "Join Red Team" : "Red team full" , 10, 300);
			context.fillText(blue.teamSize == null ? "Join Blue Team" : "Blue team full" , 510, 300);
			context.save();
			break;
		case 1: // Playing game
			//context colors and fill
			context.fillStyle = "#424242";//SET COLOR HERE	
			context.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT); 
			context.fillStyle = "#F5F6CE";//SET puck COLOR HERE
			context.font="30px Verdana";
			context.fillText("Red: " + red.score + "                                                                     " + "Blue: " + blue.score, 10, 50);
			
			if ( blue.teamSize == null || red.teamSize == null ) {
				context.fillText("Waiting on other player", 320, 300);
			}
			
			context.save();
			context.fillStyle = "#F5F6CE";//SET puck COLOR HERE
			puck.draw();
			context.fillStyle = "#FA5858";//SET p1 COLOR HERE
			red.draw();
			context.fillStyle = "#2E64FE";//SET p2 COLOR HERE
			blue.draw();
			break;
	}
	

	context.restore();
}

ws.onmessage =  function (msg) {
	var receivedObj = JSON.parse(msg.data);
	//console.log( receivedObj );

	// Checks with the received data from the broadcasts sent form the server if it is relevant
	// to be updated on the client
	if ( receivedObj.red.x != null ) { 
		red.x = receivedObj.red.x; 
		red.y = receivedObj.red.y;
		red.teamSize = receivedObj.red.teamSize;
		red.score = receivedObj.red.score;
	}
	if ( receivedObj.blue.x != null ) { 
		blue.x = receivedObj.blue.x; 
		blue.y = receivedObj.blue.y;
		blue.teamSize = receivedObj.blue.teamSize;
		blue.score = receivedObj.blue.score;
	}
	if ( receivedObj.puck.x != null ) { 
		puck.move = receivedObj.puck.move;
		puck.x = receivedObj.puck.x;
		puck.y = receivedObj.puck.y;
	}

};


main();
